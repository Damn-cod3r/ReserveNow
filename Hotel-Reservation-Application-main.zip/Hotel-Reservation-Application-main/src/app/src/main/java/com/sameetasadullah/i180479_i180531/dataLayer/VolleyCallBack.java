package com.sameetasadullah.i180479_i180531.dataLayer;

public interface VolleyCallBack {
    void onSuccess();
}